package vslab2.src.input;

public class InputThread {
    private boolean inputThreadRunning = false;

    public InputThread() {
        inputThreadRunning = true;
    }

    public void run() {
        while (inputThreadRunning) {
            
        }
    }
}
