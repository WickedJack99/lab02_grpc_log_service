package vslab2.src;

import vslab2.src.grpc.LogOuterClass;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!"); 

        // LogOuterClass.Log logMessage = LogOuterClass.Log.newBuilder()
        //     .setRowNumber(1)
        //     .setUserId("123")
        //     .setText("Hello, world!")
        //     .build();
    }
}
// Welcher User hat listen gemacht?